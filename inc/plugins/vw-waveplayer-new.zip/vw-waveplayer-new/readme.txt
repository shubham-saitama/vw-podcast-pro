=== VW Wave Player ===
Author: VW Waveplayer
Homepage: 
Author Homepage: 
Tags: audio, audio player, media, mp3, music, player, playlist, plugin, wave, waveform, vwwaveplayer, wordpress
Version: 1.0.0
Requires PHP: 7.4
Requires at least: 5.0
Tested up to: 6.3.2
License: Envato Standard License
License URI: https://codecanyon.net/licenses/standard

VwWavePlayer is a fully customizable audio plugin for WordPress. Its interface is built around the waveform of the audio file that is playing back.

== Description ==

VW WavePlayer is a fully customizable, responsive HTML5 audio plugin for WordPress. Its interface is built around the waveform of the audio file that is playing back.
Visit the official page at []()

Here is a list of the main features:

* responsive interface, with a modern looking style
* HTML5 support
* WordPress Multisite support
* four different sizes that automatically adapt to your page
* full integration with the WordPress Media Manager and WooCommerce
* Visual Editor in WordPress Post Editor
* archival of peak files for an instantaneous access to the waveforms

== Installation ==

*   In WordPress Plugins section, click on the Add new button, right beside the Plugins page title.
*   Click on the Upload Plugin button, right beside the Add Plugins page title.
*   Click on the Choose file button in order to select the location of your vwwaveplayer.zip file.
*   Browse to the location where you downloaded the vwwaveplayer.zip file.
*   Click on the Open button.
*   Once WordPress has finished uploading the plugin files, click on the Activate Plugin link.
*   The plugin is now active. You can click on the Settings link right below its name or go to Settings -> VwWavePlayer to configure its options.

== Changelog ==

= 1.0.0 =
* First release
